"""Flask configuration."""

TESTING = True
DEBUG = True
FLASK_ENV = "development"
SECRET_KEY = "development"
